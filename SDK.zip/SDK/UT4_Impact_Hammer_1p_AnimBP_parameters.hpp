#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Impact_Hammer_1p_AnimBP.Impact_Hammer_1p_AnimBP_C.ExecuteUbergraph_Impact_Hammer_1p_AnimBP
struct UImpact_Hammer_1p_AnimBP_C_ExecuteUbergraph_Impact_Hammer_1p_AnimBP_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
