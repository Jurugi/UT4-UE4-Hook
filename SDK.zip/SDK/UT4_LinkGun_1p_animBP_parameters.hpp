#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function LinkGun_1p_animBP.LinkGun_1p_animBP_C.ExecuteUbergraph_LinkGun_1p_animBP
struct ULinkGun_1p_animBP_C_ExecuteUbergraph_LinkGun_1p_animBP_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
