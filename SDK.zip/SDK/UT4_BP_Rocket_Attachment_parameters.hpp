#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_Rocket_Attachment.BP_Rocket_Attachment_C.UserConstructionScript
struct ABP_Rocket_Attachment_C_UserConstructionScript_Params
{
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
