#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function FX_GrenadeExplosion.FX_GrenadeExplosion_C.ComponentCreated
struct AFX_GrenadeExplosion_C_ComponentCreated_Params
{
	class USceneComponent**                            NewComp;                                                  // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UPrimitiveComponent**                        HitComp;                                                  // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class AActor**                                     SpawnedBy;                                                // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class AController**                                InstigatedBy;                                             // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	struct FImpactEffectNamedParameters*               EffectParams;                                             // (CPF_Parm)
};

// Function FX_GrenadeExplosion.FX_GrenadeExplosion_C.UserConstructionScript
struct AFX_GrenadeExplosion_C_UserConstructionScript_Params
{
};

// Function FX_GrenadeExplosion.FX_GrenadeExplosion_C.ExecuteUbergraph_FX_GrenadeExplosion
struct AFX_GrenadeExplosion_C_ExecuteUbergraph_FX_GrenadeExplosion_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
