#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass GibHumanBase.GibHumanBase_C
// 0x0008 (0x03D8 - 0x03D0)
class AGibHumanBase_C : public AUTGibSkeletalMesh
{
public:
	class UParticleSystemComponent*                    ParticleSystem;                                           // 0x03D0(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass GibHumanBase.GibHumanBase_C");
		return ptr;
	}


	void UserConstructionScript();
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
