// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function FX_GrenadeExplosion.FX_GrenadeExplosion_C.ComponentCreated
// (FUNC_BlueprintCosmetic, FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent, FUNC_Const)
// Parameters:
// class USceneComponent**        NewComp                        (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// class UPrimitiveComponent**    HitComp                        (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// class AActor**                 SpawnedBy                      (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// class AController**            InstigatedBy                   (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// struct FImpactEffectNamedParameters* EffectParams                   (CPF_Parm)

void AFX_GrenadeExplosion_C::ComponentCreated(class USceneComponent** NewComp, class UPrimitiveComponent** HitComp, class AActor** SpawnedBy, class AController** InstigatedBy, struct FImpactEffectNamedParameters* EffectParams)
{
	static auto fn = UObject::FindObject<UFunction>("Function FX_GrenadeExplosion.FX_GrenadeExplosion_C.ComponentCreated");

	AFX_GrenadeExplosion_C_ComponentCreated_Params params;
	params.NewComp = NewComp;
	params.HitComp = HitComp;
	params.SpawnedBy = SpawnedBy;
	params.InstigatedBy = InstigatedBy;
	params.EffectParams = EffectParams;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function FX_GrenadeExplosion.FX_GrenadeExplosion_C.UserConstructionScript
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void AFX_GrenadeExplosion_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function FX_GrenadeExplosion.FX_GrenadeExplosion_C.UserConstructionScript");

	AFX_GrenadeExplosion_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function FX_GrenadeExplosion.FX_GrenadeExplosion_C.ExecuteUbergraph_FX_GrenadeExplosion
// ()
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void AFX_GrenadeExplosion_C::ExecuteUbergraph_FX_GrenadeExplosion(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function FX_GrenadeExplosion.FX_GrenadeExplosion_C.ExecuteUbergraph_FX_GrenadeExplosion");

	AFX_GrenadeExplosion_C_ExecuteUbergraph_FX_GrenadeExplosion_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
