#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// DelegateFunction BlueprintContext.PartyContext.OnPartyTransitionStartedDelegate__DelegateSignature
struct UPartyContext_OnPartyTransitionStartedDelegate__DelegateSignature_Params
{
	EUTPartyTransition                                 PartyTransition;                                          // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// DelegateFunction BlueprintContext.PartyContext.OnPartyTransitionCompleteDelegate__DelegateSignature
struct UPartyContext_OnPartyTransitionCompleteDelegate__DelegateSignature_Params
{
	EUTPartyTransition                                 PartyTransition;                                          // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BlueprintContext.PartyContext.GetPartySize
struct UPartyContext_GetPartySize_Params
{
	int                                                ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)
};

// Function BlueprintContext.PartyContext.GetLocalPartyMemberNames
struct UPartyContext_GetLocalPartyMemberNames_Params
{
	TArray<struct FText>                               PartyMemberNamess;                                        // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor)
};

// Function BlueprintContext.PartyContext.GetLocalPartyMemberIDs
struct UPartyContext_GetLocalPartyMemberIDs_Params
{
	TArray<struct FUniqueNetIdRepl>                    PartyMemberIDs;                                           // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor)
};

// Function BlueprintContext.BlueprintContextLibrary.GetContext
struct UBlueprintContextLibrary_GetContext_Params
{
	class UObject*                                     ContextObject;                                            // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UClass*                                      Class;                                                    // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UBlueprintContextBase*                       ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
