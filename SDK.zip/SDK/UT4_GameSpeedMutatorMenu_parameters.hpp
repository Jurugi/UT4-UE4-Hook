#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.GetValue_1
struct UGameSpeedMutatorMenu_C_GetValue_1_Params
{
	float                                              ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)
};

// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.GetText_1
struct UGameSpeedMutatorMenu_C_GetText_1_Params
{
	struct FText                                       ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ReturnParm)
};

// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.Construct
struct UGameSpeedMutatorMenu_C_Construct_Params
{
};

// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.BndEvt__Button_66_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature
struct UGameSpeedMutatorMenu_C_BndEvt__Button_66_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature_Params
{
};

// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.BndEvt__Slider_0_K2Node_ComponentBoundEvent_98_OnFloatValueChangedEvent__DelegateSignature
struct UGameSpeedMutatorMenu_C_BndEvt__Slider_0_K2Node_ComponentBoundEvent_98_OnFloatValueChangedEvent__DelegateSignature_Params
{
	float                                              Value;                                                    // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.ExecuteUbergraph_GameSpeedMutatorMenu
struct UGameSpeedMutatorMenu_C_ExecuteUbergraph_GameSpeedMutatorMenu_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
