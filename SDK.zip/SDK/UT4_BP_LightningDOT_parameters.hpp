#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_LightningDOT.BP_LightningDOT_C.UserConstructionScript
struct ABP_LightningDOT_C_UserConstructionScript_Params
{
};

// Function BP_LightningDOT.BP_LightningDOT_C.StartDot
struct ABP_LightningDOT_C_StartDot_Params
{
};

// Function BP_LightningDOT.BP_LightningDOT_C.ExecuteUbergraph_BP_LightningDOT
struct ABP_LightningDOT_C_ExecuteUbergraph_BP_LightningDOT_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
