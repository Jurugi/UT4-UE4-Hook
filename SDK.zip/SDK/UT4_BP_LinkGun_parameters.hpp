#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_LinkGun.BP_LinkGun_C.GetAISelectRating
struct ABP_LinkGun_C_GetAISelectRating_Params
{
	float                                              ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)
};

// Function BP_LinkGun.BP_LinkGun_C.CanAttack
struct ABP_LinkGun_C_CanAttack_Params
{
	class AActor**                                     Target;                                                   // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	struct FVector*                                    TargetLoc;                                                // (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
	bool*                                              bDirectOnly;                                              // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	bool*                                              bPreferCurrentMode;                                       // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	unsigned char                                      BestFireMode;                                             // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
	struct FVector                                     OptimalTargetLoc;                                         // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
	bool                                               ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)
};

// Function BP_LinkGun.BP_LinkGun_C.UserConstructionScript
struct ABP_LinkGun_C_UserConstructionScript_Params
{
};

// Function BP_LinkGun.BP_LinkGun_C.PlayImpactEffects
struct ABP_LinkGun_C_PlayImpactEffects_Params
{
	struct FVector*                                    TargetLoc;                                                // (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
	unsigned char*                                     FireMode;                                                 // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	struct FVector*                                    SpawnLocation;                                            // (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
	struct FRotator*                                   SpawnRotation;                                            // (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
};

// Function BP_LinkGun.BP_LinkGun_C.DetachFromOwner
struct ABP_LinkGun_C_DetachFromOwner_Params
{
};

// Function BP_LinkGun.BP_LinkGun_C.StopFiringEffects
struct ABP_LinkGun_C_StopFiringEffects_Params
{
};

// Function BP_LinkGun.BP_LinkGun_C.ReceiveTick
struct ABP_LinkGun_C_ReceiveTick_Params
{
	float*                                             DeltaSeconds;                                             // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_LinkGun.BP_LinkGun_C.FiringInfoUpdated
struct ABP_LinkGun_C_FiringInfoUpdated_Params
{
	unsigned char*                                     InFireMode;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	unsigned char*                                     FlashCount;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	struct FVector*                                    InFlashLocation;                                          // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_LinkGun.BP_LinkGun_C.ExecuteUbergraph_BP_LinkGun
struct ABP_LinkGun_C_ExecuteUbergraph_BP_LinkGun_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
