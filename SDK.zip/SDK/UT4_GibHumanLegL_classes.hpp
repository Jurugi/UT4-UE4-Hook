#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass GibHumanLegL.GibHumanLegL_C
// 0x0000 (0x03D8 - 0x03D8)
class AGibHumanLegL_C : public AGibHumanBase_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass GibHumanLegL.GibHumanLegL_C");
		return ptr;
	}

};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
