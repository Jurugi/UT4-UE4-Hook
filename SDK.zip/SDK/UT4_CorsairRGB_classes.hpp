#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class CorsairRGB.CorsairRGB
// 0x0000 (0x0388 - 0x0388)
class ACorsairRGB : public AActor
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("Class CorsairRGB.CorsairRGB");
		return ptr;
	}

};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
