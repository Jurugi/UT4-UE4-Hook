#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass Dmg_FallingCrush.Dmg_FallingCrush_C
// 0x0000 (0x0168 - 0x0168)
class UDmg_FallingCrush_C : public UUTDmgType_FallingCrush
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass Dmg_FallingCrush.Dmg_FallingCrush_C");
		return ptr;
	}

};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
