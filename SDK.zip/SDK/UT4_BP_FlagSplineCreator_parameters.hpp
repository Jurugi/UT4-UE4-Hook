#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_FlagSplineCreator.BP_FlagSplineCreator_C.UserConstructionScript
struct ABP_FlagSplineCreator_C_UserConstructionScript_Params
{
};

// Function BP_FlagSplineCreator.BP_FlagSplineCreator_C.SplineFade__FinishedFunc
struct ABP_FlagSplineCreator_C_SplineFade__FinishedFunc_Params
{
};

// Function BP_FlagSplineCreator.BP_FlagSplineCreator_C.SplineFade__UpdateFunc
struct ABP_FlagSplineCreator_C_SplineFade__UpdateFunc_Params
{
};

// Function BP_FlagSplineCreator.BP_FlagSplineCreator_C.AddSplinePoint
struct ABP_FlagSplineCreator_C_AddSplinePoint_Params
{
	struct FVector                                     NextPoint;                                                // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_FlagSplineCreator.BP_FlagSplineCreator_C.SetTeam
struct ABP_FlagSplineCreator_C_SetTeam_Params
{
	class AUTTeamInfo**                                Team;                                                     // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_FlagSplineCreator.BP_FlagSplineCreator_C.SetPoints
struct ABP_FlagSplineCreator_C_SetPoints_Params
{
	TArray<struct FVector>*                            Points;                                                   // (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm)
};

// Function BP_FlagSplineCreator.BP_FlagSplineCreator_C.EndTrail
struct ABP_FlagSplineCreator_C_EndTrail_Params
{
};

// Function BP_FlagSplineCreator.BP_FlagSplineCreator_C.ReceiveTick
struct ABP_FlagSplineCreator_C_ReceiveTick_Params
{
	float*                                             DeltaSeconds;                                             // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_FlagSplineCreator.BP_FlagSplineCreator_C.ExecuteUbergraph_BP_FlagSplineCreator
struct ABP_FlagSplineCreator_C_ExecuteUbergraph_BP_FlagSplineCreator_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
