// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function LinkGun_1p_animBP.LinkGun_1p_animBP_C.ExecuteUbergraph_LinkGun_1p_animBP
// ()
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ULinkGun_1p_animBP_C::ExecuteUbergraph_LinkGun_1p_animBP(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function LinkGun_1p_animBP.LinkGun_1p_animBP_C.ExecuteUbergraph_LinkGun_1p_animBP");

	ULinkGun_1p_animBP_C_ExecuteUbergraph_LinkGun_1p_animBP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
