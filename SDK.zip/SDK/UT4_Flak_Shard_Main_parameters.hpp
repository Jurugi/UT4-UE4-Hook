#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Flak_Shard_Main.Flak_Shard_Main_C.UserConstructionScript
struct AFlak_Shard_Main_C_UserConstructionScript_Params
{
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
