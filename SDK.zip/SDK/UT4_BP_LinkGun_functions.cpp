// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BP_LinkGun.BP_LinkGun_C.GetAISelectRating
// (FUNC_Event, FUNC_Public, FUNC_HasOutParms, FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// float                          ReturnValue                    (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)

float ABP_LinkGun_C::GetAISelectRating()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun.BP_LinkGun_C.GetAISelectRating");

	ABP_LinkGun_C_GetAISelectRating_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function BP_LinkGun.BP_LinkGun_C.CanAttack
// (FUNC_Event, FUNC_Public, FUNC_HasOutParms, FUNC_HasDefaults, FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// class AActor**                 Target                         (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// struct FVector*                TargetLoc                      (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
// bool*                          bDirectOnly                    (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// bool*                          bPreferCurrentMode             (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// unsigned char                  BestFireMode                   (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
// struct FVector                 OptimalTargetLoc               (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
// bool                           ReturnValue                    (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)

bool ABP_LinkGun_C::CanAttack(class AActor** Target, struct FVector* TargetLoc, bool* bDirectOnly, bool* bPreferCurrentMode, unsigned char* BestFireMode, struct FVector* OptimalTargetLoc)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun.BP_LinkGun_C.CanAttack");

	ABP_LinkGun_C_CanAttack_Params params;
	params.Target = Target;
	params.TargetLoc = TargetLoc;
	params.bDirectOnly = bDirectOnly;
	params.bPreferCurrentMode = bPreferCurrentMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (BestFireMode != nullptr)
		*BestFireMode = params.BestFireMode;
	if (OptimalTargetLoc != nullptr)
		*OptimalTargetLoc = params.OptimalTargetLoc;

	return params.ReturnValue;
}


// Function BP_LinkGun.BP_LinkGun_C.UserConstructionScript
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LinkGun_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun.BP_LinkGun_C.UserConstructionScript");

	ABP_LinkGun_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkGun.BP_LinkGun_C.PlayImpactEffects
// (FUNC_Event, FUNC_Public, FUNC_HasOutParms, FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// struct FVector*                TargetLoc                      (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
// unsigned char*                 FireMode                       (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// struct FVector*                SpawnLocation                  (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
// struct FRotator*               SpawnRotation                  (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)

void ABP_LinkGun_C::PlayImpactEffects(struct FVector* TargetLoc, unsigned char* FireMode, struct FVector* SpawnLocation, struct FRotator* SpawnRotation)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun.BP_LinkGun_C.PlayImpactEffects");

	ABP_LinkGun_C_PlayImpactEffects_Params params;
	params.TargetLoc = TargetLoc;
	params.FireMode = FireMode;
	params.SpawnLocation = SpawnLocation;
	params.SpawnRotation = SpawnRotation;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkGun.BP_LinkGun_C.DetachFromOwner
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)

void ABP_LinkGun_C::DetachFromOwner()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun.BP_LinkGun_C.DetachFromOwner");

	ABP_LinkGun_C_DetachFromOwner_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkGun.BP_LinkGun_C.StopFiringEffects
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LinkGun_C::StopFiringEffects()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun.BP_LinkGun_C.StopFiringEffects");

	ABP_LinkGun_C_StopFiringEffects_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkGun.BP_LinkGun_C.ReceiveTick
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)
// Parameters:
// float*                         DeltaSeconds                   (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LinkGun_C::ReceiveTick(float* DeltaSeconds)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun.BP_LinkGun_C.ReceiveTick");

	ABP_LinkGun_C_ReceiveTick_Params params;
	params.DeltaSeconds = DeltaSeconds;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkGun.BP_LinkGun_C.FiringInfoUpdated
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)
// Parameters:
// unsigned char*                 InFireMode                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// unsigned char*                 FlashCount                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// struct FVector*                InFlashLocation                (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LinkGun_C::FiringInfoUpdated(unsigned char* InFireMode, unsigned char* FlashCount, struct FVector* InFlashLocation)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun.BP_LinkGun_C.FiringInfoUpdated");

	ABP_LinkGun_C_FiringInfoUpdated_Params params;
	params.InFireMode = InFireMode;
	params.FlashCount = FlashCount;
	params.InFlashLocation = InFlashLocation;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkGun.BP_LinkGun_C.ExecuteUbergraph_BP_LinkGun
// (FUNC_HasDefaults)
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LinkGun_C::ExecuteUbergraph_BP_LinkGun(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun.BP_LinkGun_C.ExecuteUbergraph_BP_LinkGun");

	ABP_LinkGun_C_ExecuteUbergraph_BP_LinkGun_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
