#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_LightningRifle_Proj.BP_LightningRifle_Proj_C.UserConstructionScript
struct ABP_LightningRifle_Proj_C_UserConstructionScript_Params
{
};

// Function BP_LightningRifle_Proj.BP_LightningRifle_Proj_C.DamageImpactedActor
struct ABP_LightningRifle_Proj_C_DamageImpactedActor_Params
{
	class AActor**                                     OtherActor;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UPrimitiveComponent**                        OtherComp;                                                // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	struct FVector*                                    HitLocation;                                              // (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
	struct FVector*                                    HitNormal;                                                // (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
};

// Function BP_LightningRifle_Proj.BP_LightningRifle_Proj_C.ExecuteUbergraph_BP_LightningRifle_Proj
struct ABP_LightningRifle_Proj_C_ExecuteUbergraph_BP_LightningRifle_Proj_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
