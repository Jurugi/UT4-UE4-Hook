#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.UserConstructionScript
struct ABP_LightningRifle_Attach_C_UserConstructionScript_Params
{
};

// Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.ReceiveBeginPlay
struct ABP_LightningRifle_Attach_C_ReceiveBeginPlay_Params
{
};

// Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.CheckGlow
struct ABP_LightningRifle_Attach_C_CheckGlow_Params
{
};

// Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.ExecuteUbergraph_BP_LightningRifle_Attach
struct ABP_LightningRifle_Attach_C_ExecuteUbergraph_BP_LightningRifle_Attach_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
