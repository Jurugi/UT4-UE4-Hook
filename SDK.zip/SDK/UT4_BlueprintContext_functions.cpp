// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// DelegateFunction BlueprintContext.PartyContext.OnPartyTransitionStartedDelegate__DelegateSignature
// (FUNC_MulticastDelegate, FUNC_Public, FUNC_Delegate)
// Parameters:
// EUTPartyTransition             PartyTransition                (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void UPartyContext::OnPartyTransitionStartedDelegate__DelegateSignature(EUTPartyTransition PartyTransition)
{
	static auto fn = UObject::FindObject<UFunction>("DelegateFunction BlueprintContext.PartyContext.OnPartyTransitionStartedDelegate__DelegateSignature");

	UPartyContext_OnPartyTransitionStartedDelegate__DelegateSignature_Params params;
	params.PartyTransition = PartyTransition;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// DelegateFunction BlueprintContext.PartyContext.OnPartyTransitionCompleteDelegate__DelegateSignature
// (FUNC_MulticastDelegate, FUNC_Public, FUNC_Delegate)
// Parameters:
// EUTPartyTransition             PartyTransition                (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void UPartyContext::OnPartyTransitionCompleteDelegate__DelegateSignature(EUTPartyTransition PartyTransition)
{
	static auto fn = UObject::FindObject<UFunction>("DelegateFunction BlueprintContext.PartyContext.OnPartyTransitionCompleteDelegate__DelegateSignature");

	UPartyContext_OnPartyTransitionCompleteDelegate__DelegateSignature_Params params;
	params.PartyTransition = PartyTransition;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BlueprintContext.PartyContext.GetPartySize
// (FUNC_Final, FUNC_Native, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintPure, FUNC_Const)
// Parameters:
// int                            ReturnValue                    (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)

int UPartyContext::GetPartySize()
{
	static auto fn = UObject::FindObject<UFunction>("Function BlueprintContext.PartyContext.GetPartySize");

	UPartyContext_GetPartySize_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function BlueprintContext.PartyContext.GetLocalPartyMemberNames
// (FUNC_Final, FUNC_Native, FUNC_Public, FUNC_HasOutParms, FUNC_BlueprintCallable, FUNC_BlueprintPure, FUNC_Const)
// Parameters:
// TArray<struct FText>           PartyMemberNamess              (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor)

void UPartyContext::GetLocalPartyMemberNames(TArray<struct FText>* PartyMemberNamess)
{
	static auto fn = UObject::FindObject<UFunction>("Function BlueprintContext.PartyContext.GetLocalPartyMemberNames");

	UPartyContext_GetLocalPartyMemberNames_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (PartyMemberNamess != nullptr)
		*PartyMemberNamess = params.PartyMemberNamess;
}


// Function BlueprintContext.PartyContext.GetLocalPartyMemberIDs
// (FUNC_Final, FUNC_Native, FUNC_Public, FUNC_HasOutParms, FUNC_BlueprintCallable, FUNC_BlueprintPure, FUNC_Const)
// Parameters:
// TArray<struct FUniqueNetIdRepl> PartyMemberIDs                 (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor)

void UPartyContext::GetLocalPartyMemberIDs(TArray<struct FUniqueNetIdRepl>* PartyMemberIDs)
{
	static auto fn = UObject::FindObject<UFunction>("Function BlueprintContext.PartyContext.GetLocalPartyMemberIDs");

	UPartyContext_GetLocalPartyMemberIDs_Params params;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (PartyMemberIDs != nullptr)
		*PartyMemberIDs = params.PartyMemberIDs;
}


// Function BlueprintContext.BlueprintContextLibrary.GetContext
// (FUNC_Final, FUNC_BlueprintCosmetic, FUNC_Native, FUNC_Static, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintPure)
// Parameters:
// class UObject*                 ContextObject                  (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// class UClass*                  Class                          (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// class UBlueprintContextBase*   ReturnValue                    (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)

class UBlueprintContextBase* UBlueprintContextLibrary::STATIC_GetContext(class UObject* ContextObject, class UClass* Class)
{
	static auto fn = UObject::FindObject<UFunction>("Function BlueprintContext.BlueprintContextLibrary.GetContext");

	UBlueprintContextLibrary_GetContext_Params params;
	params.ContextObject = ContextObject;
	params.Class = Class;

	auto flags = fn->FunctionFlags;
	fn->FunctionFlags |= 0x400;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
