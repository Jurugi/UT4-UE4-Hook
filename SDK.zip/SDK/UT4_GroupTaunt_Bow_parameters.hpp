#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function GroupTaunt_Bow.GroupTaunt_Bow_C.UserConstructionScript
struct AGroupTaunt_Bow_C_UserConstructionScript_Params
{
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
