#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Flak_Cannon_1p_animBP.Flak_Cannon_1p_animBP_C.ExecuteUbergraph_Flak_Cannon_1p_animBP
struct UFlak_Cannon_1p_animBP_C_ExecuteUbergraph_Flak_Cannon_1p_animBP_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
