#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass Dual_Enforcer_Attach.Dual_Enforcer_Attach_C
// 0x0010 (0x04E8 - 0x04D8)
class ADual_Enforcer_Attach_C : public AUTWeapAttachment_Enforcer
{
public:
	class UParticleSystemComponent*                    LeftMF;                                                   // 0x04D8(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UParticleSystemComponent*                    MF;                                                       // 0x04E0(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass Dual_Enforcer_Attach.Dual_Enforcer_Attach_C");
		return ptr;
	}


	void UserConstructionScript();
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
