#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_Skaarj_Dreads.BP_Skaarj_Dreads_C
// 0x0008 (0x0428 - 0x0420)
class ABP_Skaarj_Dreads_C : public AUTHat
{
public:
	class UStaticMeshComponent*                        Skaarj_Dreads;                                            // 0x0420(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_Skaarj_Dreads.BP_Skaarj_Dreads_C");
		return ptr;
	}


	void UserConstructionScript();
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
