#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_GrenadeLauncher.BP_GrenadeLauncher_C
// 0x0018 (0x0C38 - 0x0C20)
class ABP_GrenadeLauncher_C : public AUTWeap_GrenadeLauncher
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x0C20(0x0008) (CPF_ZeroConstructor, CPF_Transient, CPF_DuplicateTransient)
	class UParticleSystemComponent*                    MF;                                                       // 0x0C28(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UGrenadeDetonateIndicator_C*                 DetonatorUI;                                              // 0x0C30(0x0008) (CPF_Edit, CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_DisableEditOnInstance, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_GrenadeLauncher.BP_GrenadeLauncher_C");
		return ptr;
	}


	void UserConstructionScript();
	void ReceiveTick(float* DeltaSeconds);
	void PlayDetonationEffects();
	void ShowDetonatorUI();
	void HideDetonatorUI();
	void OnContinuedFiring();
	void AddDetonatorUIToHUD();
	void ExecuteUbergraph_BP_GrenadeLauncher(int EntryPoint);
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
