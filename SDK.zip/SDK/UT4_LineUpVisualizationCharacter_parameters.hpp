#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function LineUpVisualizationCharacter.LineUpVisualizationCharacter_C.UserConstructionScript
struct ALineUpVisualizationCharacter_C_UserConstructionScript_Params
{
};

// Function LineUpVisualizationCharacter.LineUpVisualizationCharacter_C.ReceiveBeginPlay
struct ALineUpVisualizationCharacter_C_ReceiveBeginPlay_Params
{
};

// Function LineUpVisualizationCharacter.LineUpVisualizationCharacter_C.ReceiveTick
struct ALineUpVisualizationCharacter_C_ReceiveTick_Params
{
	float*                                             DeltaSeconds;                                             // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function LineUpVisualizationCharacter.LineUpVisualizationCharacter_C.ExecuteUbergraph_LineUpVisualizationCharacter
struct ALineUpVisualizationCharacter_C_ExecuteUbergraph_LineUpVisualizationCharacter_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
