#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function LinkBeamImpactEffect.LinkBeamImpactEffect_C.UserConstructionScript
struct ALinkBeamImpactEffect_C_UserConstructionScript_Params
{
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
