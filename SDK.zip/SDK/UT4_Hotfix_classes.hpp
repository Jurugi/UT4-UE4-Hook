#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class Hotfix.OnlineHotfixManager
// 0x0388 (0x03B0 - 0x0028)
class UOnlineHotfixManager : public UObject
{
public:
	unsigned char                                      UnknownData00[0x358];                                     // 0x0028(0x0358) MISSED OFFSET
	struct FString                                     OSSName;                                                  // 0x0380(0x0010) (CPF_ZeroConstructor, CPF_Config)
	struct FString                                     HotfixManagerClassName;                                   // 0x0390(0x0010) (CPF_ZeroConstructor, CPF_Config)
	struct FString                                     DebugPrefix;                                              // 0x03A0(0x0010) (CPF_ZeroConstructor, CPF_Config)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("Class Hotfix.OnlineHotfixManager");
		return ptr;
	}


	void StartHotfixProcess();
};


// Class Hotfix.UpdateManager
// 0x0248 (0x0270 - 0x0028)
class UUpdateManager : public UObject
{
public:
	unsigned char                                      UnknownData00[0x1C8];                                     // 0x0028(0x01C8) MISSED OFFSET
	float                                              HotfixCheckCompleteDelay;                                 // 0x01F0(0x0004) (CPF_ZeroConstructor, CPF_Config, CPF_IsPlainOldData)
	float                                              UpdateCheckCompleteDelay;                                 // 0x01F4(0x0004) (CPF_ZeroConstructor, CPF_Config, CPF_IsPlainOldData)
	float                                              HotfixAvailabilityCheckCompleteDelay;                     // 0x01F8(0x0004) (CPF_ZeroConstructor, CPF_Config, CPF_IsPlainOldData)
	float                                              UpdateCheckAvailabilityCompleteDelay;                     // 0x01FC(0x0004) (CPF_ZeroConstructor, CPF_Config, CPF_IsPlainOldData)
	bool                                               bPlatformEnvironmentDetected;                             // 0x0200(0x0001) (CPF_ZeroConstructor, CPF_IsPlainOldData)
	bool                                               bInitialUpdateFinished;                                   // 0x0201(0x0001) (CPF_ZeroConstructor, CPF_IsPlainOldData)
	bool                                               bCheckHotfixAvailabilityOnly;                             // 0x0202(0x0001) (CPF_ZeroConstructor, CPF_IsPlainOldData)
	EUpdateState                                       CurrentUpdateState;                                       // 0x0203(0x0001) (CPF_ZeroConstructor, CPF_IsPlainOldData)
	int                                                WorstNumFilesPendingLoadViewed;                           // 0x0204(0x0004) (CPF_ZeroConstructor, CPF_IsPlainOldData)
	EPatchCheckResult                                  LastPatchCheckResult;                                     // 0x0208(0x0001) (CPF_ZeroConstructor, CPF_IsPlainOldData)
	EHotfixResult                                      LastHotfixResult;                                         // 0x0209(0x0001) (CPF_ZeroConstructor, CPF_IsPlainOldData)
	unsigned char                                      UnknownData01[0x2E];                                      // 0x020A(0x002E) MISSED OFFSET
	struct FDateTime                                   LastUpdateCheck[0x2];                                     // 0x0238(0x0008) (CPF_ZeroConstructor)
	EUpdateCompletionStatus                            LastCompletionResult[0x2];                                // 0x0248(0x0001) (CPF_ZeroConstructor, CPF_IsPlainOldData)
	unsigned char                                      UnknownData02[0x16];                                      // 0x024A(0x0016) MISSED OFFSET
	class UEnum*                                       UpdateStateEnum;                                          // 0x0260(0x0008) (CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UEnum*                                       UpdateCompletionEnum;                                     // 0x0268(0x0008) (CPF_ZeroConstructor, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("Class Hotfix.UpdateManager");
		return ptr;
	}

};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
