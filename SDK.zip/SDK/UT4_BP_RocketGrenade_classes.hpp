#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_RocketGrenade.BP_RocketGrenade_C
// 0x0011 (0x05B9 - 0x05A8)
class ABP_RocketGrenade_C : public AUTProj_RocketGrenade
{
public:
	class UParticleSystemComponent*                    P_Grenade_Trail;                                          // 0x05A8(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UStaticMeshComponent*                        StaticMesh1;                                              // 0x05B0(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)
	bool                                               bSetTeamColor;                                            // 0x05B8(0x0001) (CPF_Edit, CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_DisableEditOnInstance, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_RocketGrenade.BP_RocketGrenade_C");
		return ptr;
	}


	void UserConstructionScript();
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
