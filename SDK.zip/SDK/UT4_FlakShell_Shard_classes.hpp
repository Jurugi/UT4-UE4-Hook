#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass FlakShell_Shard.FlakShell_Shard_C
// 0x0000 (0x05CC - 0x05CC)
class AFlakShell_Shard_C : public AFlak_Shard_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass FlakShell_Shard.FlakShell_Shard_C");
		return ptr;
	}

};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
