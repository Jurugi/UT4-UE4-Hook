#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass LinkPrimaryHitEffect.LinkPrimaryHitEffect_C
// 0x0010 (0x03C8 - 0x03B8)
class ALinkPrimaryHitEffect_C : public AUTImpactEffect
{
public:
	class UDecalComponent*                             Decal;                                                    // 0x03B8(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UParticleSystemComponent*                    Impact;                                                   // 0x03C0(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass LinkPrimaryHitEffect.LinkPrimaryHitEffect_C");
		return ptr;
	}


	void UserConstructionScript();
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
