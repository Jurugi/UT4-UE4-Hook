#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_RallyDest_Red.BP_RallyDest_Red_C
// 0x0000 (0x03EC - 0x03EC)
class ABP_RallyDest_Red_C : public ABP_RallyDest_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_RallyDest_Red.BP_RallyDest_Red_C");
		return ptr;
	}


	void UserConstructionScript();
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
