#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_Grenade_Sticky.BP_Grenade_Sticky_C.ShowSplashRadius
struct ABP_Grenade_Sticky_C_ShowSplashRadius_Params
{
};

// Function BP_Grenade_Sticky.BP_Grenade_Sticky_C.OnRep_MyTeam
struct ABP_Grenade_Sticky_C_OnRep_MyTeam_Params
{
};

// Function BP_Grenade_Sticky.BP_Grenade_Sticky_C.SetupColor
struct ABP_Grenade_Sticky_C_SetupColor_Params
{
};

// Function BP_Grenade_Sticky.BP_Grenade_Sticky_C.UserConstructionScript
struct ABP_Grenade_Sticky_C_UserConstructionScript_Params
{
};

// Function BP_Grenade_Sticky.BP_Grenade_Sticky_C.ReceiveBeginPlay
struct ABP_Grenade_Sticky_C_ReceiveBeginPlay_Params
{
};

// Function BP_Grenade_Sticky.BP_Grenade_Sticky_C.PlayDamagedDetonationEffects
struct ABP_Grenade_Sticky_C_PlayDamagedDetonationEffects_Params
{
};

// Function BP_Grenade_Sticky.BP_Grenade_Sticky_C.PlayIdleEffects
struct ABP_Grenade_Sticky_C_PlayIdleEffects_Params
{
};

// Function BP_Grenade_Sticky.BP_Grenade_Sticky_C.OnShutdown
struct ABP_Grenade_Sticky_C_OnShutdown_Params
{
};

// Function BP_Grenade_Sticky.BP_Grenade_Sticky_C.ExecuteUbergraph_BP_Grenade_Sticky
struct ABP_Grenade_Sticky_C_ExecuteUbergraph_BP_Grenade_Sticky_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
