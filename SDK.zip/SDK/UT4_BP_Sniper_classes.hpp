#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_Sniper.BP_Sniper_C
// 0x0010 (0x0C30 - 0x0C20)
class ABP_Sniper_C : public AUTWeap_Sniper
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x0C20(0x0008) (CPF_ZeroConstructor, CPF_Transient, CPF_DuplicateTransient)
	class UParticleSystemComponent*                    MF;                                                       // 0x0C28(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_Sniper.BP_Sniper_C");
		return ptr;
	}


	void UserConstructionScript();
	void ExecuteUbergraph_BP_Sniper(int EntryPoint);
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
