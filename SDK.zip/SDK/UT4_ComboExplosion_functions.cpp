// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ComboExplosion.ComboExplosion_C.ComponentCreated
// (FUNC_BlueprintCosmetic, FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent, FUNC_Const)
// Parameters:
// class USceneComponent**        NewComp                        (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// class UPrimitiveComponent**    HitComp                        (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// class AActor**                 SpawnedBy                      (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// class AController**            InstigatedBy                   (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// struct FImpactEffectNamedParameters* EffectParams                   (CPF_Parm)

void AComboExplosion_C::ComponentCreated(class USceneComponent** NewComp, class UPrimitiveComponent** HitComp, class AActor** SpawnedBy, class AController** InstigatedBy, struct FImpactEffectNamedParameters* EffectParams)
{
	static auto fn = UObject::FindObject<UFunction>("Function ComboExplosion.ComboExplosion_C.ComponentCreated");

	AComboExplosion_C_ComponentCreated_Params params;
	params.NewComp = NewComp;
	params.HitComp = HitComp;
	params.SpawnedBy = SpawnedBy;
	params.InstigatedBy = InstigatedBy;
	params.EffectParams = EffectParams;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ComboExplosion.ComboExplosion_C.UserConstructionScript
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void AComboExplosion_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function ComboExplosion.ComboExplosion_C.UserConstructionScript");

	AComboExplosion_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
