#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_UTDmg_LightningHeadshot.BP_UTDmg_LightningHeadshot_C.PlayDeathEffects
struct UBP_UTDmg_LightningHeadshot_C_PlayDeathEffects_Params
{
	class AUTCharacter**                               DyingPawn;                                                // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_UTDmg_LightningHeadshot.BP_UTDmg_LightningHeadshot_C.GetDeathAnim
struct UBP_UTDmg_LightningHeadshot_C_GetDeathAnim_Params
{
	class AUTCharacter**                               DyingPawn;                                                // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UAnimMontage*                                ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)
};

// Function BP_UTDmg_LightningHeadshot.BP_UTDmg_LightningHeadshot_C.OverrideDeathSound
struct UBP_UTDmg_LightningHeadshot_C_OverrideDeathSound_Params
{
	class AUTCharacter**                               Victim;                                                   // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	bool                                               ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
