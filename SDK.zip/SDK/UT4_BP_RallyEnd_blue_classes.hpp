#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_RallyEnd_blue.BP_RallyEnd_blue_C
// 0x0000 (0x03A0 - 0x03A0)
class ABP_RallyEnd_blue_C : public AUTReplicatedEmitter
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_RallyEnd_blue.BP_RallyEnd_blue_C");
		return ptr;
	}

};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
