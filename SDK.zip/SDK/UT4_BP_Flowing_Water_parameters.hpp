#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_Flowing_Water.BP_Flowing_Water_C.UserConstructionScript
struct ABP_Flowing_Water_C_UserConstructionScript_Params
{
};

// Function BP_Flowing_Water.BP_Flowing_Water_C.ReceiveActorBeginOverlap
struct ABP_Flowing_Water_C_ReceiveActorBeginOverlap_Params
{
	class AActor**                                     OtherActor;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_Flowing_Water.BP_Flowing_Water_C.ReceiveActorEndOverlap
struct ABP_Flowing_Water_C_ReceiveActorEndOverlap_Params
{
	class AActor**                                     OtherActor;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_Flowing_Water.BP_Flowing_Water_C.ExecuteUbergraph_BP_Flowing_Water
struct ABP_Flowing_Water_C_ExecuteUbergraph_BP_Flowing_Water_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
