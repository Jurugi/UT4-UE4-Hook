#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function LinkGun_Anim_BP.LinkGun_Anim_BP_C.BlueprintUpdateAnimation
struct ULinkGun_Anim_BP_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function LinkGun_Anim_BP.LinkGun_Anim_BP_C.ExecuteUbergraph_LinkGun_Anim_BP
struct ULinkGun_Anim_BP_C_ExecuteUbergraph_LinkGun_Anim_BP_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
