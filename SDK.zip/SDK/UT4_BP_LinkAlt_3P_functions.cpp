// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.SetColors
// (FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// struct FLinearColor            NewPrimeColor                  (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LinkAlt_3P_C::SetColors(const struct FLinearColor& NewPrimeColor)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.SetColors");

	ABP_LinkAlt_3P_C_SetColors_Params params;
	params.NewPrimeColor = NewPrimeColor;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.SetMaterialParams
// (FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LinkAlt_3P_C::SetMaterialParams()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.SetMaterialParams");

	ABP_LinkAlt_3P_C_SetMaterialParams_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.Deactivate
// (FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LinkAlt_3P_C::Deactivate()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.Deactivate");

	ABP_LinkAlt_3P_C_Deactivate_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.UserConstructionScript
// (FUNC_Event, FUNC_Public, FUNC_HasDefaults, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LinkAlt_3P_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.UserConstructionScript");

	ABP_LinkAlt_3P_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.ReceiveBeginPlay
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)

void ABP_LinkAlt_3P_C::ReceiveBeginPlay()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.ReceiveBeginPlay");

	ABP_LinkAlt_3P_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.ReceiveTick
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)
// Parameters:
// float*                         DeltaSeconds                   (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LinkAlt_3P_C::ReceiveTick(float* DeltaSeconds)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.ReceiveTick");

	ABP_LinkAlt_3P_C_ReceiveTick_Params params;
	params.DeltaSeconds = DeltaSeconds;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.MaterialCheck
// (FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LinkAlt_3P_C::MaterialCheck()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.MaterialCheck");

	ABP_LinkAlt_3P_C_MaterialCheck_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.ExecuteUbergraph_BP_LinkAlt_3P
// (FUNC_HasDefaults)
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LinkAlt_3P_C::ExecuteUbergraph_BP_LinkAlt_3P(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkAlt_3P.BP_LinkAlt_3P_C.ExecuteUbergraph_BP_LinkAlt_3P");

	ABP_LinkAlt_3P_C_ExecuteUbergraph_BP_LinkAlt_3P_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
