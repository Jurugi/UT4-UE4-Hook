// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function ImpactHammerShieldProj.ImpactHammerShieldProj_C.UserConstructionScript
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void AImpactHammerShieldProj_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function ImpactHammerShieldProj.ImpactHammerShieldProj_C.UserConstructionScript");

	AImpactHammerShieldProj_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ImpactHammerShieldProj.ImpactHammerShieldProj_C.ReceiveBeginPlay
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)

void AImpactHammerShieldProj_C::ReceiveBeginPlay()
{
	static auto fn = UObject::FindObject<UFunction>("Function ImpactHammerShieldProj.ImpactHammerShieldProj_C.ReceiveBeginPlay");

	AImpactHammerShieldProj_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ImpactHammerShieldProj.ImpactHammerShieldProj_C.ReceiveTick
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)
// Parameters:
// float*                         DeltaSeconds                   (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void AImpactHammerShieldProj_C::ReceiveTick(float* DeltaSeconds)
{
	static auto fn = UObject::FindObject<UFunction>("Function ImpactHammerShieldProj.ImpactHammerShieldProj_C.ReceiveTick");

	AImpactHammerShieldProj_C_ReceiveTick_Params params;
	params.DeltaSeconds = DeltaSeconds;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function ImpactHammerShieldProj.ImpactHammerShieldProj_C.ExecuteUbergraph_ImpactHammerShieldProj
// ()
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void AImpactHammerShieldProj_C::ExecuteUbergraph_ImpactHammerShieldProj(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function ImpactHammerShieldProj.ImpactHammerShieldProj_C.ExecuteUbergraph_ImpactHammerShieldProj");

	AImpactHammerShieldProj_C_ExecuteUbergraph_ImpactHammerShieldProj_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
