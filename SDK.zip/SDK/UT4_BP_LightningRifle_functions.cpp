// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BP_LightningRifle.BP_LightningRifle_C.CanAttack
// (FUNC_Event, FUNC_Public, FUNC_HasOutParms, FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// class AActor**                 Target                         (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// struct FVector*                TargetLoc                      (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
// bool*                          bDirectOnly                    (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// bool*                          bPreferCurrentMode             (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// unsigned char                  BestFireMode                   (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
// struct FVector                 OptimalTargetLoc               (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
// bool                           ReturnValue                    (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)

bool ABP_LightningRifle_C::CanAttack(class AActor** Target, struct FVector* TargetLoc, bool* bDirectOnly, bool* bPreferCurrentMode, unsigned char* BestFireMode, struct FVector* OptimalTargetLoc)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle.BP_LightningRifle_C.CanAttack");

	ABP_LightningRifle_C_CanAttack_Params params;
	params.Target = Target;
	params.TargetLoc = TargetLoc;
	params.bDirectOnly = bDirectOnly;
	params.bPreferCurrentMode = bPreferCurrentMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (BestFireMode != nullptr)
		*BestFireMode = params.BestFireMode;
	if (OptimalTargetLoc != nullptr)
		*OptimalTargetLoc = params.OptimalTargetLoc;

	return params.ReturnValue;
}


// Function BP_LightningRifle.BP_LightningRifle_C.UserConstructionScript
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LightningRifle_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle.BP_LightningRifle_C.UserConstructionScript");

	ABP_LightningRifle_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LightningRifle.BP_LightningRifle_C.ReceiveBeginPlay
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)

void ABP_LightningRifle_C::ReceiveBeginPlay()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle.BP_LightningRifle_C.ReceiveBeginPlay");

	ABP_LightningRifle_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LightningRifle.BP_LightningRifle_C.TipArc
// (FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LightningRifle_C::TipArc()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle.BP_LightningRifle_C.TipArc");

	ABP_LightningRifle_C_TipArc_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LightningRifle.BP_LightningRifle_C.OnBringUp
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)

void ABP_LightningRifle_C::OnBringUp()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle.BP_LightningRifle_C.OnBringUp");

	ABP_LightningRifle_C_OnBringUp_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LightningRifle.BP_LightningRifle_C.ExecuteUbergraph_BP_LightningRifle
// (FUNC_HasDefaults)
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LightningRifle_C::ExecuteUbergraph_BP_LightningRifle(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle.BP_LightningRifle_C.ExecuteUbergraph_BP_LightningRifle");

	ABP_LightningRifle_C_ExecuteUbergraph_BP_LightningRifle_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
