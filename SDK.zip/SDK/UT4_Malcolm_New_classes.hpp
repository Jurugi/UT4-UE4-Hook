#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass Malcolm_New.Malcolm_New_C
// 0x0000 (0x04D8 - 0x04D8)
class AMalcolm_New_C : public AHumanMaleBase_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass Malcolm_New.Malcolm_New_C");
		return ptr;
	}

};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
