// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.GetValue_1
// (FUNC_Public, FUNC_HasOutParms, FUNC_BlueprintCallable, FUNC_BlueprintEvent, FUNC_BlueprintPure)
// Parameters:
// float                          ReturnValue                    (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)

float UGameSpeedMutatorMenu_C::GetValue_1()
{
	static auto fn = UObject::FindObject<UFunction>("Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.GetValue_1");

	UGameSpeedMutatorMenu_C_GetValue_1_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.GetText_1
// (FUNC_Public, FUNC_HasOutParms, FUNC_HasDefaults, FUNC_BlueprintCallable, FUNC_BlueprintEvent, FUNC_BlueprintPure)
// Parameters:
// struct FText                   ReturnValue                    (CPF_Parm, CPF_OutParm, CPF_ReturnParm)

struct FText UGameSpeedMutatorMenu_C::GetText_1()
{
	static auto fn = UObject::FindObject<UFunction>("Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.GetText_1");

	UGameSpeedMutatorMenu_C_GetText_1_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.Construct
// (FUNC_BlueprintCosmetic, FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)

void UGameSpeedMutatorMenu_C::Construct()
{
	static auto fn = UObject::FindObject<UFunction>("Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.Construct");

	UGameSpeedMutatorMenu_C_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.BndEvt__Button_66_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature
// (FUNC_BlueprintEvent)

void UGameSpeedMutatorMenu_C::BndEvt__Button_66_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature()
{
	static auto fn = UObject::FindObject<UFunction>("Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.BndEvt__Button_66_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature");

	UGameSpeedMutatorMenu_C_BndEvt__Button_66_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.BndEvt__Slider_0_K2Node_ComponentBoundEvent_98_OnFloatValueChangedEvent__DelegateSignature
// (FUNC_BlueprintEvent)
// Parameters:
// float                          Value                          (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void UGameSpeedMutatorMenu_C::BndEvt__Slider_0_K2Node_ComponentBoundEvent_98_OnFloatValueChangedEvent__DelegateSignature(float Value)
{
	static auto fn = UObject::FindObject<UFunction>("Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.BndEvt__Slider_0_K2Node_ComponentBoundEvent_98_OnFloatValueChangedEvent__DelegateSignature");

	UGameSpeedMutatorMenu_C_BndEvt__Slider_0_K2Node_ComponentBoundEvent_98_OnFloatValueChangedEvent__DelegateSignature_Params params;
	params.Value = Value;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.ExecuteUbergraph_GameSpeedMutatorMenu
// (FUNC_HasDefaults)
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void UGameSpeedMutatorMenu_C::ExecuteUbergraph_GameSpeedMutatorMenu(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function GameSpeedMutatorMenu.GameSpeedMutatorMenu_C.ExecuteUbergraph_GameSpeedMutatorMenu");

	UGameSpeedMutatorMenu_C_ExecuteUbergraph_GameSpeedMutatorMenu_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
