// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.UserConstructionScript
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LightningRifle_Attach_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.UserConstructionScript");

	ABP_LightningRifle_Attach_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.ReceiveBeginPlay
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)

void ABP_LightningRifle_Attach_C::ReceiveBeginPlay()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.ReceiveBeginPlay");

	ABP_LightningRifle_Attach_C_ReceiveBeginPlay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.CheckGlow
// (FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LightningRifle_Attach_C::CheckGlow()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.CheckGlow");

	ABP_LightningRifle_Attach_C_CheckGlow_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.ExecuteUbergraph_BP_LightningRifle_Attach
// (FUNC_HasDefaults)
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LightningRifle_Attach_C::ExecuteUbergraph_BP_LightningRifle_Attach(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LightningRifle_Attach.BP_LightningRifle_Attach_C.ExecuteUbergraph_BP_LightningRifle_Attach");

	ABP_LightningRifle_Attach_C_ExecuteUbergraph_BP_LightningRifle_Attach_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
