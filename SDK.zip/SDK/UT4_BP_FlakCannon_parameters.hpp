#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_FlakCannon.BP_FlakCannon_C.UserConstructionScript
struct ABP_FlakCannon_C_UserConstructionScript_Params
{
};

// Function BP_FlakCannon.BP_FlakCannon_C.ReceiveTick
struct ABP_FlakCannon_C_ReceiveTick_Params
{
	float*                                             DeltaSeconds;                                             // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_FlakCannon.BP_FlakCannon_C.ExecuteUbergraph_BP_FlakCannon
struct ABP_FlakCannon_C_ExecuteUbergraph_BP_FlakCannon_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
