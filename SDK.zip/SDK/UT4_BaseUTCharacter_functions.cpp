// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BaseUTCharacter.BaseUTCharacter_C.OnShockComboExplode
// (FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABaseUTCharacter_C::OnShockComboExplode()
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.OnShockComboExplode");

	ABaseUTCharacter_C_OnShockComboExplode_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BaseUTCharacter.BaseUTCharacter_C.SpawnActorHelper
// (FUNC_Public, FUNC_HasOutParms, FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// class UClass*                  Class                          (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
// struct FTransform              SpawnTransform                 (CPF_Parm, CPF_IsPlainOldData)
// class AActor*                  Spawned_Actor                  (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABaseUTCharacter_C::SpawnActorHelper(class UClass* Class, const struct FTransform& SpawnTransform, class AActor** Spawned_Actor)
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.SpawnActorHelper");

	ABaseUTCharacter_C_SpawnActorHelper_Params params;
	params.Class = Class;
	params.SpawnTransform = SpawnTransform;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Spawned_Actor != nullptr)
		*Spawned_Actor = params.Spawned_Actor;
}


// Function BaseUTCharacter.BaseUTCharacter_C.GetGameTime
// (FUNC_Public, FUNC_HasOutParms, FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// float                          GameTime                       (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABaseUTCharacter_C::GetGameTime(float* GameTime)
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.GetGameTime");

	ABaseUTCharacter_C_GetGameTime_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (GameTime != nullptr)
		*GameTime = params.GameTime;
}


// Function BaseUTCharacter.BaseUTCharacter_C.UserConstructionScript
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABaseUTCharacter_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.UserConstructionScript");

	ABaseUTCharacter_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BaseUTCharacter.BaseUTCharacter_C.PlayTakeHitEffects
// (FUNC_BlueprintCosmetic, FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)

void ABaseUTCharacter_C::PlayTakeHitEffects()
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.PlayTakeHitEffects");

	ABaseUTCharacter_C_PlayTakeHitEffects_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BaseUTCharacter.BaseUTCharacter_C.OnRep_Invisible
// (FUNC_BlueprintCosmetic, FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)

void ABaseUTCharacter_C::OnRep_Invisible()
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.OnRep_Invisible");

	ABaseUTCharacter_C_OnRep_Invisible_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BaseUTCharacter.BaseUTCharacter_C.OnSlide
// (FUNC_Event, FUNC_Public, FUNC_HasOutParms, FUNC_BlueprintEvent)
// Parameters:
// struct FVector*                SlideLocation                  (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
// struct FVector*                SlideDir                       (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)

void ABaseUTCharacter_C::OnSlide(struct FVector* SlideLocation, struct FVector* SlideDir)
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.OnSlide");

	ABaseUTCharacter_C_OnSlide_Params params;
	params.SlideLocation = SlideLocation;
	params.SlideDir = SlideDir;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BaseUTCharacter.BaseUTCharacter_C.DrawPoint
// (FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// struct FVector                 Location                       (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABaseUTCharacter_C::DrawPoint(const struct FVector& Location)
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.DrawPoint");

	ABaseUTCharacter_C_DrawPoint_Params params;
	params.Location = Location;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BaseUTCharacter.BaseUTCharacter_C.ExecuteUbergraph_BaseUTCharacter
// ()
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABaseUTCharacter_C::ExecuteUbergraph_BaseUTCharacter(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.ExecuteUbergraph_BaseUTCharacter");

	ABaseUTCharacter_C_ExecuteUbergraph_BaseUTCharacter_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BaseUTCharacter.BaseUTCharacter_C.NewEventDispatcher__DelegateSignature
// (FUNC_Public, FUNC_Delegate, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABaseUTCharacter_C::NewEventDispatcher__DelegateSignature()
{
	static auto fn = UObject::FindObject<UFunction>("Function BaseUTCharacter.BaseUTCharacter_C.NewEventDispatcher__DelegateSignature");

	ABaseUTCharacter_C_NewEventDispatcher__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
