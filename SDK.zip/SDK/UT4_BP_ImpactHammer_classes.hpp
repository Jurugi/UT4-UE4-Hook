#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_ImpactHammer.BP_ImpactHammer_C
// 0x0008 (0x0C38 - 0x0C30)
class ABP_ImpactHammer_C : public AUTWeap_ImpactHammer
{
public:
	class UParticleSystemComponent*                    MF;                                                       // 0x0C30(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_ImpactHammer.BP_ImpactHammer_C");
		return ptr;
	}


	void UserConstructionScript();
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
