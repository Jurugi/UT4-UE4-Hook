// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.OverrideFiringEffects
// (FUNC_Event, FUNC_Public, FUNC_HasOutParms, FUNC_HasDefaults, FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// bool                           ReturnValue                    (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)

bool ABP_LinkGun_Attach_C::OverrideFiringEffects()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.OverrideFiringEffects");

	ABP_LinkGun_Attach_C_OverrideFiringEffects_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.UserConstructionScript
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void ABP_LinkGun_Attach_C::UserConstructionScript()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.UserConstructionScript");

	ABP_LinkGun_Attach_C_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.StopFiringEffects
// (FUNC_Event, FUNC_Public, FUNC_BlueprintCallable, FUNC_BlueprintEvent)
// Parameters:
// bool*                          bIgnoreCurrentMode             (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LinkGun_Attach_C::StopFiringEffects(bool* bIgnoreCurrentMode)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.StopFiringEffects");

	ABP_LinkGun_Attach_C_StopFiringEffects_Params params;
	params.bIgnoreCurrentMode = bIgnoreCurrentMode;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.ReceiveEndPlay
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)
// Parameters:
// TEnumAsByte<EEndPlayReason>*   EndPlayReason                  (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LinkGun_Attach_C::ReceiveEndPlay(TEnumAsByte<EEndPlayReason>* EndPlayReason)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.ReceiveEndPlay");

	ABP_LinkGun_Attach_C_ReceiveEndPlay_Params params;
	params.EndPlayReason = EndPlayReason;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.ExecuteUbergraph_BP_LinkGun_Attach
// ()
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void ABP_LinkGun_Attach_C::ExecuteUbergraph_BP_LinkGun_Attach(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.ExecuteUbergraph_BP_LinkGun_Attach");

	ABP_LinkGun_Attach_C_ExecuteUbergraph_BP_LinkGun_Attach_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
