#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function GrenadeDetonateIndicator.GrenadeDetonateIndicator_C.Get_GrenadeCount_Text_1
struct UGrenadeDetonateIndicator_C_Get_GrenadeCount_Text_1_Params
{
	struct FText                                       ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ReturnParm)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
