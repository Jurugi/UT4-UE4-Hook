#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.OverrideFiringEffects
struct ABP_LinkGun_Attach_C_OverrideFiringEffects_Params
{
	bool                                               ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)
};

// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.UserConstructionScript
struct ABP_LinkGun_Attach_C_UserConstructionScript_Params
{
};

// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.StopFiringEffects
struct ABP_LinkGun_Attach_C_StopFiringEffects_Params
{
	bool*                                              bIgnoreCurrentMode;                                       // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.ReceiveEndPlay
struct ABP_LinkGun_Attach_C_ReceiveEndPlay_Params
{
	TEnumAsByte<EEndPlayReason>*                       EndPlayReason;                                            // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function BP_LinkGun_Attach.BP_LinkGun_Attach_C.ExecuteUbergraph_BP_LinkGun_Attach
struct ABP_LinkGun_Attach_C_ExecuteUbergraph_BP_LinkGun_Attach_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
