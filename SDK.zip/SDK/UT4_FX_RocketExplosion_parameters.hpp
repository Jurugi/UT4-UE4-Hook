#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function FX_RocketExplosion.FX_RocketExplosion_C.ComponentCreated
struct AFX_RocketExplosion_C_ComponentCreated_Params
{
	class USceneComponent**                            NewComp;                                                  // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UPrimitiveComponent**                        HitComp;                                                  // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class AActor**                                     SpawnedBy;                                                // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class AController**                                InstigatedBy;                                             // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	struct FImpactEffectNamedParameters*               EffectParams;                                             // (CPF_Parm)
};

// Function FX_RocketExplosion.FX_RocketExplosion_C.UserConstructionScript
struct AFX_RocketExplosion_C_UserConstructionScript_Params
{
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
