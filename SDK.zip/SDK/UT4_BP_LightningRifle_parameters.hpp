#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_LightningRifle.BP_LightningRifle_C.CanAttack
struct ABP_LightningRifle_C_CanAttack_Params
{
	class AActor**                                     Target;                                                   // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	struct FVector*                                    TargetLoc;                                                // (CPF_ConstParm, CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
	bool*                                              bDirectOnly;                                              // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	bool*                                              bPreferCurrentMode;                                       // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
	unsigned char                                      BestFireMode;                                             // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
	struct FVector                                     OptimalTargetLoc;                                         // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReferenceParm, CPF_IsPlainOldData)
	bool                                               ReturnValue;                                              // (CPF_Parm, CPF_OutParm, CPF_ZeroConstructor, CPF_ReturnParm, CPF_IsPlainOldData)
};

// Function BP_LightningRifle.BP_LightningRifle_C.UserConstructionScript
struct ABP_LightningRifle_C_UserConstructionScript_Params
{
};

// Function BP_LightningRifle.BP_LightningRifle_C.ReceiveBeginPlay
struct ABP_LightningRifle_C_ReceiveBeginPlay_Params
{
};

// Function BP_LightningRifle.BP_LightningRifle_C.TipArc
struct ABP_LightningRifle_C_TipArc_Params
{
};

// Function BP_LightningRifle.BP_LightningRifle_C.OnBringUp
struct ABP_LightningRifle_C_OnBringUp_Params
{
};

// Function BP_LightningRifle.BP_LightningRifle_C.ExecuteUbergraph_BP_LightningRifle
struct ABP_LightningRifle_C_ExecuteUbergraph_BP_LightningRifle_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
