#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_Grenade.BP_Grenade_C.OnRep_MyTeam
struct ABP_Grenade_C_OnRep_MyTeam_Params
{
};

// Function BP_Grenade.BP_Grenade_C.FetchInstigator
struct ABP_Grenade_C_FetchInstigator_Params
{
};

// Function BP_Grenade.BP_Grenade_C.SetupColor
struct ABP_Grenade_C_SetupColor_Params
{
};

// Function BP_Grenade.BP_Grenade_C.UserConstructionScript
struct ABP_Grenade_C_UserConstructionScript_Params
{
};

// Function BP_Grenade.BP_Grenade_C.ReceiveBeginPlay
struct ABP_Grenade_C_ReceiveBeginPlay_Params
{
};

// Function BP_Grenade.BP_Grenade_C.ExecuteUbergraph_BP_Grenade
struct ABP_Grenade_C_ExecuteUbergraph_BP_Grenade_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
