#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AwesomComboReward.AwesomComboReward_C
// 0x0000 (0x0090 - 0x0090)
class UAwesomComboReward_C : public UUTRewardMessage
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass AwesomComboReward.AwesomComboReward_C");
		return ptr;
	}

};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
