#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass BP_LightningRifle_Proj.BP_LightningRifle_Proj_C
// 0x0018 (0x0550 - 0x0538)
class ABP_LightningRifle_Proj_C : public AUTProj_Lightning
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x0538(0x0008) (CPF_ZeroConstructor, CPF_Transient, CPF_DuplicateTransient)
	class UAudioComponent*                             Audio;                                                    // 0x0540(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)
	class UParticleSystemComponent*                    Flight;                                                   // 0x0548(0x0008) (CPF_BlueprintVisible, CPF_ZeroConstructor, CPF_IsPlainOldData)

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass BP_LightningRifle_Proj.BP_LightningRifle_Proj_C");
		return ptr;
	}


	void UserConstructionScript();
	void DamageImpactedActor(class AActor** OtherActor, class UPrimitiveComponent** OtherComp, struct FVector* HitLocation, struct FVector* HitNormal);
	void ExecuteUbergraph_BP_LightningRifle_Proj(int EntryPoint);
};


#ifdef _MSC_VER
	#pragma pack(pop)
#endif
