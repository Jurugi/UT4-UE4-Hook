#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ArenaMutatorMenu.ArenaMutatorMenu_C.Construct
struct UArenaMutatorMenu_C_Construct_Params
{
};

// Function ArenaMutatorMenu.ArenaMutatorMenu_C.BndEvt__Button_8_K2Node_ComponentBoundEvent_34_OnButtonClickedEvent__DelegateSignature
struct UArenaMutatorMenu_C_BndEvt__Button_8_K2Node_ComponentBoundEvent_34_OnButtonClickedEvent__DelegateSignature_Params
{
};

// Function ArenaMutatorMenu.ArenaMutatorMenu_C.BndEvt__TranslocatorCheck_K2Node_ComponentBoundEvent_106_OnCheckBoxComponentStateChanged__DelegateSignature
struct UArenaMutatorMenu_C_BndEvt__TranslocatorCheck_K2Node_ComponentBoundEvent_106_OnCheckBoxComponentStateChanged__DelegateSignature_Params
{
	bool                                               bIsChecked;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function ArenaMutatorMenu.ArenaMutatorMenu_C.BndEvt__WeaponCombo_K2Node_ComponentBoundEvent_105_OnSelectionChangedEvent__DelegateSignature
struct UArenaMutatorMenu_C_BndEvt__WeaponCombo_K2Node_ComponentBoundEvent_105_OnSelectionChangedEvent__DelegateSignature_Params
{
	struct FString                                     SelectedItem;                                             // (CPF_Parm, CPF_ZeroConstructor)
	TEnumAsByte<ESelectInfo>                           SelectionType;                                            // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function ArenaMutatorMenu.ArenaMutatorMenu_C.ExecuteUbergraph_ArenaMutatorMenu
struct UArenaMutatorMenu_C_ExecuteUbergraph_ArenaMutatorMenu_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
