#pragma once

// Unreal Tournament 4 (4.15) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_Sniper.BP_Sniper_C.UserConstructionScript
struct ABP_Sniper_C_UserConstructionScript_Params
{
};

// Function BP_Sniper.BP_Sniper_C.ExecuteUbergraph_BP_Sniper
struct ABP_Sniper_C_ExecuteUbergraph_BP_Sniper_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
